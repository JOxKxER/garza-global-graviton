from src.api import app
CLUSTER_CONFIG = {
    "batch_size": 250000,
    "scale_factor": 1.0,
    "port": 8000
}
import logging
import argparse
import asyncio
import time
import datetime
import uvicorn
from pathlib import Path
import numpy as np

from src.worker import AsyncNetworkCoordinator, run_worker_node
from src.ledger import ConsensusLedger
from src.ingest_stream import generate_workload_stream

async def worker_task(connect_host, port, w_id):
    await asyncio.sleep(0.3)
    await run_worker_node(host=connect_host, port=port, worker_id=w_id)

async def master_loop(coordinator, min_workers):
    ledger = ConsensusLedger()
    await coordinator.start_server()
    print(f"[*] Production Cluster Coordinator Active on {coordinator.host}:{coordinator.port}")
    await coordinator.wait_for_workers(min_workers=min_workers, timeout=60.0)
    print(f"[+] {min_workers} Compute Nodes Verified & Locked into Merkle Ring.")

    stream = generate_workload_stream(batch_size=CLUSTER_CONFIG["batch_size"])

    for dataset in stream:
        # Check if stream is paused from Web UI
        while CLUSTER_CONFIG.get("paused", False):
            await asyncio.sleep(0.5)

        t0 = time.time()
        try:
            scale = CLUSTER_CONFIG.get("scale_factor", 2.0)
            success, msg, result, tree = await coordinator.dispatch_job(dataset, scale=scale)
            lat = round((time.time() - t0) * 1000.0, 2)
            
            if success and result is not None and tree is not None:
                proofs = [
                    {
                        "worker_id": w_id,
                        "task_id": idx,
                        "block_hash": tree.leaves[idx] if idx < len(tree.leaves) else "0"*64,
                        "latency_ms": max(round(lat / max(len(coordinator.workers), 1), 2), 0.3),
                        "metadata": {"status": "VERIFIED_CONSENSUS"}
                    }
                    for idx, w_id in enumerate(coordinator.workers.keys())
                ]
                
                batch_id = ledger.record_batch(
                    merkle_root=tree.root_hash,
                    elements_count=len(result),
                    worker_proofs=proofs
                )
                
                print(f"[BLOCK #{batch_id:05d} COMMITTED] Root: {tree.root_hash[:16]}... | Vectors: {len(result):,d} | Latency: {lat}ms")
        except Exception as e:
            print(f"[CLUSTER ERROR] {e}")
            
        await asyncio.sleep(0.75)

async def run_production_cluster(args):
    coordinator = AsyncNetworkCoordinator(host=args.host, port=args.port)

    config = uvicorn.Config(app=app, host=args.host, port=args.api_port, log_level="warning")
    server = uvicorn.Server(config)

    print(f"\n=======================================================")
    print(f" ?? GARZA GLOBAL GRAVITON - MISSION CONTROL")
    print(f"=======================================================")
    print(f"[*] Dashboard : http://localhost:{args.api_port}")
    print(f"[*] Network   : tcp://{args.host}:{args.port}")
    print(f"=======================================================\n")
    
    tasks = [
        server.serve(),
        master_loop(coordinator, args.min_workers)
    ]

    connect_host = "127.0.0.1" if args.host == "0.0.0.0" else args.host

    for i in range(args.min_workers):
        tasks.append(worker_task(connect_host, args.port, f"node_worker_{i+1:02d}"))

    await asyncio.gather(*tasks)

def main():
    parser = argparse.ArgumentParser(description="Garza Global Graviton Mission Control")
    parser.add_argument("--host", type=str, default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--api-port", type=int, default=8000)
    parser.add_argument("--min-workers", type=int, default=2)
    args = parser.parse_args()

    try:
        asyncio.run(run_production_cluster(args))
    except KeyboardInterrupt:
        print("\n[*] Cluster stopped.")

if __name__ == "__main__":
    main()


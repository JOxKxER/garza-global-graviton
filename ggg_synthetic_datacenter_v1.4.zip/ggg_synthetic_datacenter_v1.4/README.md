# ggg_synthetic_datacenter_v1.4

Garza Global Graviton (GGG) Synthetic Data Center -- standalone offline release.

## What's in this bundle

- `src/` -- the full core engine (`organs/`, `c2/`, `llm/`, and every other
  subsystem module used by the benchmark suite and the organ core).
- `index.html` -- the local platform UI (retro plaque, #GGG manifesto,
  physics benchmark table, and the local Ollama bridge).
- `run_benchmarks.py` -- the 61-module benchmark suite.
- `run_node.py` / `run_node.bat` -- launcher that boots the organ core and
  opens the local interface.

## Quick start (100% offline)

1. Install Python 3.10+ and the dependencies:

   ```
   pip install -r requirements.txt
   ```

2. Launch the node:

   ```
   python run_node.py
   ```

   (Windows users can instead double-click `run_node.bat`.)

   This boots the `SyntheticOrganCore`, runs one warm-up cycle across the
   Heart/Liver/Lungs/Immune System daemons, and opens `index.html` in your
   default browser -- no server or internet connection required.

## Optional: local Ollama bridge

The bundled `index.html` includes a hardened local Ollama bridge (chat +
live benchmark widgets). To use it:

1. Install [Ollama](https://ollama.com) and start it locally.
2. Pull a lightweight model, e.g.:

   ```
   ollama pull llama3.2:3b
   ```

3. In the page, confirm the endpoint reads `http://localhost:11434` and
   click **Check Status** -- the badge should turn **ONLINE**.

The bridge only ever talks to `localhost` / `127.0.0.1` / `[::1]`; any other
host is rejected client-side before a request is sent, keeping the platform
fully air-gapped by construction.

## Running the 61-module benchmark suite

```
python run_benchmarks.py
```

This exercises every subsystem module (aerodynamics, astrodynamics, c2,
comms, cryptography, distributed, estimation, guidance, hardware, physics,
power, quantum, robotics, routing, security, swarm, telemetry, and the
organ core) and prints a per-module timing report.

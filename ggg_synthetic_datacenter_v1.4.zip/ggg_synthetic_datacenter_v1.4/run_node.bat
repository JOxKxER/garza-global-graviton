@echo off
python "%~dp0run_node.py"
pause

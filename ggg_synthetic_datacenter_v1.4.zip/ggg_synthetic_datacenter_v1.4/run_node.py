"""GGG Synthetic Data Center - offline node launcher.

Initializes the SyntheticOrganCore for one warm-up cycle (confirming the
engine is alive) and opens the bundled index.html in the default browser.
No network access is required; everything runs from local files.
"""

import sys
import webbrowser
from pathlib import Path

BUNDLE_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(BUNDLE_ROOT))

from src.organs.synthetic_organ_core import SyntheticOrganCore  # noqa: E402


def main() -> None:
    core = SyntheticOrganCore(capacity_bytes=1 << 20, target_hz=1000.0)
    print("Booting Synthetic Data Center organ core...")
    for sample in core.run_cycle():
        print(f"  [{sample.organ_name}] {sample.as_dict()}")

    index_path = BUNDLE_ROOT / "index.html"
    if index_path.exists():
        print(f"Opening local interface: {index_path}")
        webbrowser.open(index_path.as_uri())
    else:
        print("[WARN] index.html not found in bundle; skipping browser launch.")


if __name__ == "__main__":
    main()
